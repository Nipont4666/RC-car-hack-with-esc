  
#ifndef __RF24_INCLUDES_H__
#define __RF24_INCLUDES_H__

  #define RF24_RPi
  #include "RPi/bcm2835.h" 
  #include "RPi/RF24_arch_config.h"
  #include "RPi/interrupt.h"
  
#endif
